/* Custome javascript goes here */
// IIFE
(   function(){
    function Start(){
        console.log("%c App Started..")
    }

    window.addEventListener("load",Start);
})();