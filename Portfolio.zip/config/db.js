module.exports = {
    // local MongoDb deployment
    "URI": "mongodb://localhost/demo"
   // "URI" : "mongodb://<Dipesh>:<Dipesh@123>@ds058548.mlab.com:58548/comp308-w2019-lession4a"
   //"URI" : "mongodb://thomas:a123456@ds044989.mlab.com:44989/comp308-w2019-lesson4a"
   //"URI": "mongodb://Dipesh:Dipesh123@ds121105.mlab.com:21105/dipesh"
}